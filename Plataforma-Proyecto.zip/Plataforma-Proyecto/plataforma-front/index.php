<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Plataforma London Institute 2018</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--Cargar librerias-->

  <!-- Jquery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <!-- Bootstrap -->
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>




  <!-- Estilos -->
  <link rel='stylesheet' type='text/css' href="./css/style.css" />

  <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">

 


</head>
<body>

<!--HEADER -->

    <header id="header">

  <nav class="navbar navbar-default navbar-static-top marginBottom-0" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <!--LOGO-->
    <a class="navbar-brand" href="">
      <img src="./imagenes/logo.png" id="logo" />
    </a>
    </div>

    <div class="collapse navbar-collapse" id="navbar-collapse-1">
        <ul class="nav navbar-nav">


          <li><a href="">
          <span class="glyphicon glyphicon-home" aria-hidden="true"></span>
          Home
        </a></li>



<li class="dropdown"><a href="#"  class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-th-large" aria-hidden="true"></span> Estudio <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <li><a href="#">Abrir Estudio</a></li>
              <li><a href="">Crear Estudio</a></li>
              <li><a href="#">Salir</a></li>

                </ul>
            </li>




            <li class="dropdown"><a href="#"  class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> Clientes <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                          <li><a href="#">Nuevo</a></li>
                          <li><a href="#">Buscar</a></li>
                          <li><a href="#">Eliminar</a></li>
                          <li class="divider"></li>
                          <li class="dropdown dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Documentos</a>

                  </li>
                                <li class="dropdown dropdown-submenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Principal</a>

                  </li>
                            </ul>
                        </li>






                        <li class="dropdown"><a href="#"  class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-menu-hamburger"></span> Modelo <b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                      <li><a href="#">Crear Modelo</a></li>
                                      <li><a href="#">Organizar</a></li>


                                        </ul>
                                    </li>









            <li class="dropdown"><a href="#"  class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-wrench"></span> Herramientas <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#">Calculadora</a></li>
                    <li><a href="#">Calculos Financieros</a></li>
                    <li><a href="#">Explorar Documentos docAdm</a></li>
                    <li><a href="#">Autocompletar Documentos</a></li>
                    <li><a href="#">Usuarios</a></li>
                    <li><a href="#">Indice Protocolo</a></li>

                </ul>
            </li>


            <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-signal"></span> Tablas <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#">Rubros</a></li>
                    <li><a href="#">Monedas</a></li>

                </ul>
            </li>



            <li><a href="">
            <span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span>
            Ayuda
          </a></li>

            <li><a href="">
         <span class="glyphicon glyphicon-off"></span>
          Salir
       </a></li>
        </ul>





    </div><!-- /.navbar-collapse -->
</nav>





</header>
<!-- termina header -->





<!--LOGIN -->
<div class="wrapper" style="margin:0px !important;">

  <form class="form-signin">
    <h2 class="form-signin-heading">Plataforma Login</h2>
    <br/>

    <input type="text" class="form-control" name="nombreusuario" placeholder="Nombre de Usuario" required="" autofocus="" />

    



    <input type="password" class="form-control" name="passw" placeholder="Contraseña"
     required=""/>

    


    <label class="checkbox" id="check_box">
      <input type="checkbox" value="remember-me" id="rememberMe" name="rememberMe">Recordarme
    </label>
    <button class="btn btn-lg btn-primary btn-block" type="button">Acceder</button>
  </form>
</div>
<!--termina login -->








  
</body>
</html>