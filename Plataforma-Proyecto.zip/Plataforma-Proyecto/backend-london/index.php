<?php


	echo '<title>Symfony3 Installed</title><div style="background: #e9ffed; border: 1px solid #b0dab7; padding: 15px;" align="center" >
	<font size="5" color="#182e7a">Symfony3 is installed successfully.</font><br /><br />
	<font size="4">Symfony3 is a Framework, so doesn\'t have an index page.<br /><br />
	Symfony aims to speed up the creation and maintenance of web applications, and to replace the repetitive coding tasks by power, control and pleasure.

Symfony is aimed at building robust applications in an enterprise context. This means that you have full control over the configuration: from the directory structure to the foreign libraries, almost everything can be customized. </font></div>';

?>