import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'registro',
  templateUrl: '../views/registro.html'
})
export class RegistroComponent implements OnInit{

  public title:string;

  constructor(
    //private _route:ActivatedRoute,
    //private _router:Router
  ){
    this.title='Componente de registro';

  }
  ngOnInit(){
    console.log('El componente registro ha sido cargado correctamente');
  }

}
