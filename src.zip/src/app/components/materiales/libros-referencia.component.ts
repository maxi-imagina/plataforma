import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UserService } from '../../services/user.service';


@Component({
  selector: 'libros-curso',
  templateUrl: '../../views/materiales/libros-referencia.html',
  providers: [UserService]
})
export class LibrosReferenciaComponent implements OnInit{

  public title:string;
  public user;
  public identity;
  public token;


  constructor(
    private _route:ActivatedRoute,
    private _router:Router,
    private _userService: UserService

  ){
    this.title='Libros Referencia';
    this.user={
      "email":"",
      "passw":"",
      "getHash":true
    };
    this.identity=this._userService.getIdentity();
    this.token= this._userService.getToken();

  }
  ngOnInit(){
    this.redirectIfNotIdentity();

  }



  redirectIfNotIdentity(){
    let identity = this._userService.getIdentity();
    if(identity == null){
      this._router.navigate(["/login"]);
    }
  }

}
