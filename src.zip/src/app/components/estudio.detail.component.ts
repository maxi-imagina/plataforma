import {Component, OnInit} from '@angular/core';
import {Router, ActivatedRoute, Params} from '@angular/router';
import {UserService} from '../services/user.service';
import {EstudioService} from '../services/estudio.service';
import {Estudio} from '../models/estudio';

@Component({
  selector: 'estudio-detail',
  templateUrl: '../views/estudio.detail.html',
  providers: [UserService, EstudioService];
})

export class EstudioDetailComponent implements OnInit{
  public identity;
  public token;
  public estudio:Estudio;

  constructor(
    private _userService: UserService,
    private _estudioService: EstudioService,
    private _route: ActivatedRoute,
    private _router: Router
  ){

    this.identity = this._userService.getIdentity();
    this.token = this._userService.getToken();

  }

  ngOnInit(){
    if(this.identity && this.identity.sub){
      //llamada al servicio de estudios para sacar un estudio
      this.getEstudio();
      //llamada al metodo de este componente
    }else{
      this._router.navigate(['/login']);
    }
  }

  getEstudio(){
    this._route.params.forEach((params: Params) =>{
      let id = +params ['id'];
      this._estudioService.getEstudio(this.token, id).subscribe(
          response =>{

            this.estudio = response.data;

            if(response.status =='success'){

              if(this.estudio.idusuario.idusuario == this.identity.sub){
                //PODEMOS VER LA TAREA
              }else{
              this._router.navigate(['/'])
            }

            }else{
              this._router.navigate(['/login']);
            }
          },
          error =>{
            console.log(<any>error);
          }
      );
    });
  }

  eliminarEstudio(id){
    console.log('Has dado click a eliminar');
    this._estudioService.deleteEstudio(this.token, id).subscribe(
      response =>{
        if(response.status == 'success'){
          this._router.navigate(['/']);
        }else{
          alert('No se ha eliminado el estudio');
        }
      },
      error=>{
        console.log(<any>error);
      }
    );
  }


}
