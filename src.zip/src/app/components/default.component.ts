import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UserService } from '../services/user.service';
import { EstudioService } from '../services/estudio.service';
import { Estudio } from '../models/estudio';

@Component({
  selector: 'default',
  templateUrl: '../views/default.html',
  providers: [UserService, EstudioService]
})
export class DefaultComponent implements OnInit{

  public title:string;
  public user;
  public identity;
  public token;
  public estudios: Array<Estudio>;
  public pages;
  public pagePrev;
  public pageNext;
  public loading;

  constructor(
    private _route:ActivatedRoute,
    private _router:Router,
    private _userService: UserService,
    private _estudioService: EstudioService
  ){
    this.title='Home';
    this.user={
      "email":"",
      "passw":"",
      "getHash":true
    };
    this.identity=this._userService.getIdentity();
    this.token= this._userService.getToken();

  }
  ngOnInit(){
    this.redirectIfNotIdentity();
    this.getAllEstudios();
  }

  getAllEstudios(){
    this._route.params.forEach((params:Params)=>{
       let page = +params['page'];

       if(!page){
         page=1;
       }
       this.loading = 'show';
       this._estudioService.getEstudios(this.token, page).subscribe(
         response => {
           if(response.status=='success'){
             this.estudios = response.data;

             this.loading= 'hide';

             //total de paginas
             this.pages = [];
             for(let i=0; i < response.total_pages; i++){
                this.pages.push(i);
             }

             //pagina anterior
             if(page >= 2){
             this.pagePrev = (page - 1);
             }else{
             this.pagePrev = page;
            }

            //pagina siguiente
            if(page < response.total_pages){
            this.pageNext = (page +1);
            }else{
            this.pageNext = page;
            }
           }

         },
         error => {
           console.log(<any>error);
         }
       );
    });
  }

  redirectIfNotIdentity(){
    let identity = this._userService.getIdentity();
    if(identity == null){
      this._router.navigate(["/login"]);
    }
  }

}
