import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UserService } from '../services/user.service';
import { EstudioService } from '../services/estudio.service';
import { Estudio } from '../models/estudio';

@Component({
  selector: 'agregar-estudio',
  templateUrl: '../views/agregar-estudio.html',
  providers: [UserService, EstudioService]
})
export class AgregarEstudioComponent implements OnInit{

  public title:string;
  public identity;
  public estudio: Estudio;
  public token;
  public status;


  constructor(
    private _userService: UserService,
    private _estudioService: EstudioService,
    private _route:ActivatedRoute,
    private _router:Router

  ){
    this.title='Componente Agregar Estudio';
    this.identity=this._userService.getIdentity();
    this.token=this._userService.getToken();

  }
  ngOnInit(){
    if(this.identity==null && !this.identity.sub){
      this._router.navigate(['/login']);
    }else{
      this.estudio = new Estudio(1, '', '', 'new', 'null');
    }

  }

  onSubmit(){
    console.log(this.estudio);

    this._estudioService.create(this.token, this.estudio).subscribe(
      response => {
        this.status=response.status;

        if(this.status != 'success'){
          this.status = 'error';
        }else{
          this.estudio=response.estudio;
          //this._router.navigate(['/estudio', this.estudio.id]);
          this._router.navigate(['/']);
        }
      },
      error =>{
        console.log(<any>error);
      }
    );
  }

}
