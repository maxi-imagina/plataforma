import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UserService } from '../services/user.service';
import { EstudioService } from '../services/estudio.service';
import { Estudio } from '../models/estudio';

@Component({
  selector: 'editar-estudio',
  templateUrl: '../views/agregar-estudio.html',
  providers: [UserService, EstudioService]
})
export class EditarEstudioComponent implements OnInit{

  public title:string;
  public identity;
  public estudio: Estudio;
  public token;
  public status;
  public loading;


  constructor(
    private _userService: UserService,
    private _estudioService: EstudioService,
    private _route:ActivatedRoute,
    private _router:Router

  ){
    this.title='Componente Modificar Estudio';
    this.identity=this._userService.getIdentity();
    this.token=this._userService.getToken();

  }
  ngOnInit(){
    if(this.identity==null && !this.identity.sub){
      this._router.navigate(['/login']);
    }else{
      //this.estudio = new Estudio(1, '', '', 'new', 'null');
      this.getEstudio();

    }

  }

  getEstudio(){
    this.loading ='show';
    this._route.params.forEach((params: Params) =>{
      let id = +params ['id'];
      this._estudioService.getEstudio(this.token, id).subscribe(
          response =>{

            this.estudio = response.data;
            this.loading ='hide';

            if(response.status =='success'){

              if(this.estudio.idusuario.idusuario == this.identity.sub){
                //PODEMOS VER LA TAREA
              }else{
              this._router.navigate(['/'])
            }

            }else{
              this._router.navigate(['/login']);
            }
          },
          error =>{
            console.log(<any>error);
          }
      );
    });
  }




  onSubmit(){
    console.log(this.estudio);
    this._route.params.forEach((params: Params) =>{

      let id = +params ['id'];
      

    this._estudioService.update(this.token, this.estudio, id).subscribe(
      response => {
        this.status=response.status;

        if(this.status != 'success'){
          this.status = 'error';
        }else{
          this.estudio=response.estudio;
          //this._router.navigate(['/estudio', this.estudio.id]);
          this._router.navigate(['/']);
        }
      },
      error =>{
        console.log(<any>error);
      }
    );
  });
  }

}
