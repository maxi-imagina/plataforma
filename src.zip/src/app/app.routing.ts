import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './components/login.component';
import { RegistroComponent } from './components/registro.component';
import { DefaultComponent } from './components/default.component';
import { AgregarEstudioComponent} from './components/agregar-estudio.component';
import { EditarEstudioComponent } from './components/estudio.edit.component.ts';
import { EstudioDetailComponent } from './components/estudio.detail.component';

const appRoutes: Routes = [
  {path:'', component: DefaultComponent},
  {path:'index', component: DefaultComponent},
  {path:'index/:page', component: DefaultComponent},
  {path:'login', component: LoginComponent},
  {path:'login/:id', component: LoginComponent},
  {path:'registro', component: RegistroComponent},
  {path:'agregarEstudio',component:AgregarEstudioComponent},
  {path:'editarEstudio/:id',component:EditarEstudioComponent},
  {path:'estudio/:id',component:EstudioDetailComponent},
  {path:'**', component: LoginComponent}
];

export const appRoutingProviders: any[]=[];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
