import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './components/login.component';
import { RegistroComponent } from './components/registro.component';
import { DefaultComponent } from './components/default.component';


//MATERIALES
import { MaterialesComponent } from './components/materiales.component';
import { ActualizacionDocenteComponent } from './components/materiales/actualizacion-docente.component';
import { AdministracionComponent } from './components/materiales/administracion.component';
import { EvaluacionComponent } from './components/materiales/evaluacion.component';
import { LibrosCursoComponent } from './components/materiales/libros-curso.component';
import { CourseBooksComponent } from './components/materiales/libros-curso/course-books.component';
import { HistoryBooksComponent } from './components/materiales/libros-curso/history-books.component';
import { ProgramasInglesComponent } from './components/materiales/programas-ingles.component';
import { LibrosReferenciaComponent } from './components/materiales/libros-referencia.component';
import { LenguasModernasComponent } from './components/materiales/lenguas-modernas.component';


import { PortuguesComponent } from './components/materiales/lenguas-modernas/portugues.component';
import { ChinoComponent } from './components/materiales/lenguas-modernas/chino.component';
import { JaponesComponent } from './components/materiales/lenguas-modernas/japones.component';
import { CoreanoComponent } from './components/materiales/lenguas-modernas/coreano.component';
import { ItalianoComponent } from './components/materiales/lenguas-modernas/italiano.component';
import { FrancesComponent } from './components/materiales/lenguas-modernas/frances.component';
import { EspanolExtranjerosComponent } from './components/materiales/lenguas-modernas/espanol-extranjeros.component';
import { Portugues2016Component } from './components/materiales/lenguas-modernas/portugues/portugues-2016.component';

//EXAMENES
import { ExamenesComponent } from './components/examenes.component';
import { MayTestsComponent } from './components/examenes/may-tests.component';
import { AugustTestsComponent } from './components/examenes/august-tests.component';
import { IHWOComponent } from './components/examenes/ihwo.component';
import { MockExamsComponent } from './components/examenes/mock-exams.component';


const appRoutes: Routes = [
  {path:'', component: DefaultComponent},
  {path:'index', component: DefaultComponent},
  {path:'index/:page', component: DefaultComponent},
  {path:'login', component: LoginComponent},
  {path:'login/:id', component: LoginComponent},
  {path:'registro', component: RegistroComponent},
  {path:'materiales', component: MaterialesComponent},
  {path:'materiales/actualizacion-docente', component: ActualizacionDocenteComponent},
  {path:'materiales/administracion', component: AdministracionComponent},
  {path:'materiales/evaluacion', component: EvaluacionComponent},
  {path:'materiales/libros-curso', component: LibrosCursoComponent},
  {path:'materiales/libros-curso/course-books', component: CourseBooksComponent},
  {path:'materiales/libros-curso/history-books', component: HistoryBooksComponent},
  {path:'materiales/programas-ingles', component: ProgramasInglesComponent},
  {path:'materiales/libros-referencia', component: LibrosReferenciaComponent},
  {path:'materiales/lenguas-modernas', component: LenguasModernasComponent},
  {path:'materiales/lenguas-modernas/portugues', component: PortuguesComponent},
  {path:'materiales/lenguas-modernas/chino', component: ChinoComponent},
  {path:'materiales/lenguas-modernas/japones', component: JaponesComponent},
  {path:'materiales/lenguas-modernas/coreano', component: CoreanoComponent},
  {path:'materiales/lenguas-modernas/italiano', component:  ItalianoComponent},
  {path:'materiales/lenguas-modernas/frances', component:  FrancesComponent},
  {path:'materiales/lenguas-modernas/espanol-extranjeros', component: EspanolExtranjerosComponent},
  {path:'materiales/lenguas-modernas/portugues/portugues-2016', component: Portugues2016Component},
  {path:'examenes', component: ExamenesComponent},
  {path:'examenes/may-tests', component: MayTestsComponent},
  {path:'examenes/august-tests', component: AugustTestsComponent},
  {path:'examenes/ihwo-tests', component: IHWOComponent},
  {path:'examenes/mock-exams', component: MockExamsComponent},
  {path:'**', component: LoginComponent}
];

export const appRoutingProviders: any[]=[];
export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
