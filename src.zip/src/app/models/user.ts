export class User{
    constructor(
      public idusuario:number,
      public role: string,
      public name: string,
      public nombre_usuario:string,
      public paswusuario:string,
      public createdAt

    ){

    }

}
