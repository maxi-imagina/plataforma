export class Estudio{
    constructor(
      public idestudio:number,
      public nombre_estudio:string,
      public descripcion_estudio:string,
      public createdAt,
      public updatedAt
    ){

    }

}
