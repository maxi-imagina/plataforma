import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import "rxjs/add/operator/map";
import { Observable } from 'rxjs/Observable';
import { GLOBAL } from './global';

@Injectable()
export class EstudioService{
  public url;

  constructor(
    private _http:Http
  ){
    this.url = GLOBAL.url;
  }
  //METODO CREAR ESTUDIOS
  create(token, estudio){
     let json = JSON.stringify(estudio);
     let params = "json="+json+"&authorization="+token;
     let headers = new Headers({'Content-Type':'application/x-www-form-urlencoded'});

     return this._http.post(this.url+'/estudio/newEstudio', params, { headers: headers}).map(res=>res.json());
  }

  //METODO LISTADO DE ESTUDIOS
  getEstudios(token, page=null){
    let params="authorization="+token;
    let headers = new Headers({'Content-Type':'application/x-www-form-urlencoded'});

    if(page==null){
      page=1;
    }

    return this._http.post(this.url+'/estudio/listEstudios?page='+page, params, {headers: headers})
                     .map(res=>res.json());


  }

  //METODO DETALLE DEL ESTUDIO
  getEstudio(token, id){

    let params="authorization="+token;
    let headers = new Headers({'Content-Type':'application/x-www-form-urlencoded'});

    return this._http.post(this.url + '/estudio/detailEstudio/'+id, params, {headers:headers})
                     .map(res=>res.json());

  }
  //METODO EDITAR
  update(token, estudio, id){
    let json = JSON.stringify(estudio);
    let params = "json="+json+"&authorization="+token;
    let headers = new Headers({'Content-Type':'application/x-www-form-urlencoded'});

    return this._http.post(this.url+'/estudio/editEstudio/'+ id, params, {headers:headers})
                     .map(res => res.json());

  }

  //METODO ELIMINAR ESTUDIO
  deleteEstudio(token, id){

    let params="authorization="+token;
    let headers = new Headers({'Content-Type':'application/x-www-form-urlencoded'});

    return this._http.post(this.url + '/estudio/borrarEstudio/'+id, params, {headers:headers})
                     .map(res=>res.json());

  }




}
