export var GLOBAL={
  url:'http://localhost:8888/docadm-backend/symfony/web/app_dev.php'
};
