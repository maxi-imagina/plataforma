export var GLOBAL={
  url:'http://localhost:8888/plataforma-backend/symfony/web/app_dev.php'
};
