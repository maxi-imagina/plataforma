import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import {routing, appRoutingProviders} from './app.routing';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login.component';
import { RegistroComponent } from './components/registro.component';
import { DefaultComponent } from './components/default.component';
import { AgregarEstudioComponent } from './components/agregar-estudio.component';
import { EditarEstudioComponent } from './components/estudio.edit.component';
import { EstudioDetailComponent } from './components/estudio.detail.component';
import { GenerateDatePipe } from './pipes/generate.date.pipe'

//servicios


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistroComponent,
    DefaultComponent,
    AgregarEstudioComponent,
    EditarEstudioComponent,
    EstudioDetailComponent,
    GenerateDatePipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [
    appRoutingProviders

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
