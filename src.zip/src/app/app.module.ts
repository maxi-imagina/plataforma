import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import {routing, appRoutingProviders} from './app.routing';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login.component';
import { RegistroComponent } from './components/registro.component';
import { DefaultComponent } from './components/default.component';

//MATERIALES
import { MaterialesComponent } from './components/materiales.component';
import { ActualizacionDocenteComponent } from './components/materiales/actualizacion-docente.component';
import { AdministracionComponent } from './components/materiales/administracion.component';
import { EvaluacionComponent } from './components/materiales/evaluacion.component';
import { LibrosCursoComponent } from './components/materiales/libros-curso.component';
import { CourseBooksComponent } from './components/materiales/libros-curso/course-books.component';
import { HistoryBooksComponent } from './components/materiales/libros-curso/history-books.component';
import { ProgramasInglesComponent } from './components/materiales/programas-ingles.component';
import { LibrosReferenciaComponent } from './components/materiales/libros-referencia.component';
import { LenguasModernasComponent } from './components/materiales/lenguas-modernas.component';
import { ChinoComponent } from './components/materiales/lenguas-modernas/chino.component';
import { JaponesComponent } from './components/materiales/lenguas-modernas/japones.component';
import { FrancesComponent } from './components/materiales/lenguas-modernas/frances.component';
import { ItalianoComponent } from './components/materiales/lenguas-modernas/italiano.component';
import { CoreanoComponent } from './components/materiales/lenguas-modernas/coreano.component';
import { PortuguesComponent } from './components/materiales/lenguas-modernas/portugues.component';
import { EspanolExtranjerosComponent } from './components/materiales/lenguas-modernas/espanol-extranjeros.component';
import { Portugues2016Component } from './components/materiales/lenguas-modernas/portugues/portugues-2016.component';



//EXAMENES
import { ExamenesComponent } from './components/examenes.component';
import { MayTestsComponent } from './components/examenes/may-tests.component';
import { AugustTestsComponent } from './components/examenes/august-tests.component';
import { IHWOComponent } from './components/examenes/ihwo.component';
import { MockExamsComponent } from './components/examenes/mock-exams.component';

import { GenerateDatePipe } from './pipes/generate.date.pipe'

//servicios


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistroComponent,
    DefaultComponent,
    MaterialesComponent,
    ActualizacionDocenteComponent,
    AdministracionComponent,
    EvaluacionComponent,
    LibrosCursoComponent,
    CourseBooksComponent,
    HistoryBooksComponent,
    ProgramasInglesComponent,
    LibrosReferenciaComponent,
    LenguasModernasComponent,
    PortuguesComponent,
    ChinoComponent,
    JaponesComponent,
    ItalianoComponent,
    FrancesComponent,
    CoreanoComponent,
    EspanolExtranjerosComponent,
    Portugues2016Component,
    ExamenesComponent,
    MayTestsComponent,
    AugustTestsComponent,
    IHWOComponent,
    MockExamsComponent,
    GenerateDatePipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [
    appRoutingProviders

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
