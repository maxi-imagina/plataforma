<?php
namespace AppBundle\Services;

use Firebase\JWT\JWT;

class JwtAuth{

  public $manager;
  public $key;

  public function __construct($manager){
    $this->manager=$manager;
    $this->key='clavesecreta31!!"·4234234234234';
  }

  public function signup($nombreusuario, $passw, $getHash=null){
    $user = $this ->manager->getRepository('BackendBundle:Usuario')->findOneBy(array(

      "nombreusuario" => $nombreusuario,
      "passw" => $passw

    ));

    $signup=false;

    if(is_object($user)){
      $signup=true;
    }

    if($signup==true){

      //GENERAR TOKEN JWT
      $token = array(
        "sub" => $user ->getIdusuario(),
        "nombreusuario"=>$user->getNombreusuario(),
        "passw"=>$user->getPassw(),
        "iat" => time(),
        "exp" => time()+(7*24*60*60)
      );

      $jwt = JWT::encode($token, $this->key,'HS256');

      $decoded =JWT::decode($jwt, $this->key, array('HS256'));

      if($getHash == null){
        $data=$jwt;
      }else{
        $data =$decoded;
      }



  }else {
    $data=array(
      'status'=>'error',
      'data'=>'login failed'
    );
  }

    return $data;
  }

  public function checkToken($jwt, $getIdentity=false){
    $auth=false;
    try{
    $decoded =  JWT::decode($jwt,$this->key,array('HS256'));
  }catch(\UnexpectedValueException $e){

    $auth=false;

  }catch(\DomainException $e){
    $auth=false;
  }

  if(isset($decoded) && is_object($decoded) && isset($decoded->sub)){
      $auth =true;
  }
  else{
    $auth=false;
  }

  if($getIdentity==false){
    return $auth;
  }else{
    return $decoded;
  }


  }

}
