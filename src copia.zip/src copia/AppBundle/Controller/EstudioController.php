<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use BackendBundle\Entity\Usuario;
use BackendBundle\Entity\Estudio;
use AppBundle\Services\Helpers;
use AppBundle\Services\JwtAuth;

class EstudioController extends Controller{

    public function newAction(Request $request, $id = null){

      $helpers = $this->get(Helpers::class);
      $jwt_auth = $this->get(JwtAuth::class);

      $token = $request->get('authorization', null);
      $authCheck = $jwt_auth -> checkToken($token);

      if($authCheck){
        $identity = $jwt_auth -> checkToken($token, true);
        $json = $request -> get("json", null);

        if($json != null){

          $params = json_decode($json);



          $user_id = ($identity->sub != null) ? $identity->sub :null;
          $nombre_estudio = (isset($params->nombre_estudio)) ? $params->nombre_estudio : null;
          $descripcion_estudio = (isset($params->descripcion_estudio)) ? $params->descripcion_estudio:null;
          $created_at = new \Datetime('now');
          $updated_at = new \Datetime('now');

          if($user_id =! null && $nombre_estudio != null){
            //CREAR ESTUDIO
            $em = $this->getDoctrine()->getManager();

            $user = $em-> getRepository('BackendBundle:Usuario')->findOneBy(array(
                "idusuario" => $user_id
            ));

            if($id==null){

            $estudio = new Estudio();
            $estudio -> setIdUsuario($user);
            $estudio -> setNombreEstudio($nombre_estudio);
            $estudio -> setDescripcionEstudio($descripcion_estudio);
            $estudio ->setCreatedAt($created_at);
            $estudio ->setUpdatedAt($updated_at);

            $em -> persist($estudio);
            $em -> flush();


            $data=array(
              "status"=>"success",
              "code"=>200,
              "msg" =>""
            );


          }  else{

            $estudio = $em->getRepository('BackendBundle:Estudio')->findOneBy(array(
              "idusuario"=>$user_id
            ));

            if(isset($identity->sub) && $identity->sub==$estudio->getIdusuario()->getIdusuario()){




              $estudio -> setNombreEstudio($nombre_estudio);
              $estudio -> setDescripcionEstudio($descripcion_estudio);
              $estudio ->setUpdatedAt($updated_at);

              $em -> persist($estudio);
              $em -> flush();

              $data=array(
                "status"=>"success",
                "code"=>200,
                "msg" =>""
              );

            }else{
              $data=array(
                "status"=>"error",
                "code"=>400,
                "msg" =>"Usuario no fue actualizado"
              );

            }
          }

          }else {
            $data=array(
              "status"=>"error",
              "code"=>400,
              "msg" =>"Estudio no fue validado"
            );
          }



        }else {
          $data=array(
            "status"=>"error",
            "code"=>400,
            "msg" =>"Estudio no creado"
          );
        }

        $data=array(
          "status"=>"success",
          "code"=>200,
          "msg" =>""
        );

      }else {
        $data=array(
          "status"=>"error",
          "code"=>400,
          "msg" =>"Authorization not valid"
        );
      }
/*
      return $helpers->json($data);

      $json = $request ->get("json",null);
      $params = json_decode($json);

      $data = array(
        'status'=>'error',
        'code' =>400,
        'msg' =>'Estudio no creado!!'
      );

      if($json != null){
        $nombre_estudio = (isset($params->nombre_estudio)) ? $params->nombre_estudio : null;
        $descripcion_estudio = (isset($params->descripcion_estudio)) ? $params->descripcion_estudio:null;
        $created_at = new \Datetime("now");
        $updated_at = new \Datetime("now");

        if($nombre_estudio !=null){

          $estudio = new Estudio();

          $estudio->setNombreEstudio($nombre_estudio);
          $estudio->setDescripcionEstudio($descripcion_estudio);
          $estudio->setCreatedAt($created_at);
          $estudio->setUpdatedAt($updated_at);

          $em= $this->getDoctrine()->getManager();
          $isset_estudio = $em->getRepository('BackendBundle:Estudio')->findBy(array(
            "nombreEstudio"=>$nombre_estudio
          ));

          if(count($isset_estudio)==0){
              $em->persist($estudio);
              $em->flush();

              $data = array(
                'status'=>'success',
                'code' =>200,
                'msg' =>'El estudio ha sido creado correctamente'
              );

          }
          else{

            $data = array(
              'status'=>'error',
              'code' =>400,
              'msg' =>'El estudio esta duplicado!!'
            );

          }


        }


      }
*/
      return $helpers->json($data);
    }

    public function EstudiosAction(Request $request){
      //carga servicio helpers
      $helpers = $this->get(Helpers::class);
      //carga servicio de jwt y comprueba token
      $jwt_auth = $this->get(JwtAuth::class);

      //recoge el token
      $token = $request->get('authorization', null);

      //valida el token
      $authCheck = $jwt_auth -> checkToken($token);

      if($authCheck){
        $identity = $jwt_auth -> checkToken($token, true);//informacion usuario logueado

      $em = $this->getDoctrine()->getManager();

      $dql = "SELECT e from BackendBundle:Estudio e WHERE e.idusuario = {$identity->sub} ORDER BY e.idestudio DESC";
      $query = $em -> createQuery($dql);

      $page = $request->query->getInt('page', 1);
      $paginator = $this->get('knp_paginator');
      $items_per_page = 10;

      $pagination = $paginator -> paginate($query, $page, $items_per_page);
      $total_items_count = $pagination ->getTotalItemCount();// cuenta todos los registros que hay en la query



      $data = array(
          'status'=> 'success',
          'code'=>'200',
          'total_items_count'=> $total_items_count,
          'page_actual'=>$page,
          'items_per_page'=>$items_per_page,
          'total_pages'=> ceil($total_items_count / $items_per_page),
          'data' =>$pagination
        );




      }else{

        $data = array(
          'status'=> 'error',
          'code'=>'400',
          'msg'=> 'authorization not valid'
        );

      }
      return $helpers -> json($data);

}

      public function estudioAction(Request $request, $id=null){

        //carga servicio helpers
        $helpers = $this->get(Helpers::class);
        //carga servicio de jwt y comprueba token
        $jwt_auth = $this->get(JwtAuth::class);

        //recoge el token
        $token = $request->get('authorization', null);

        //valida el token
        $authCheck = $jwt_auth -> checkToken($token);

        if($authCheck){
          $identity = $jwt_auth -> checkToken($token, true);//informacion usuario logueado

          $em = $this->getDoctrine()->getManager();

          $estudio = $em->getRepository('BackendBundle:Estudio')->findOneBy(array(
            "idestudio"=>$id
          ));

          if($estudio && is_object($estudio) && $identity->sub== $estudio->getIdusuario()->getIdusuario()){

            $data = array(
              'status'=> 'success',
              'code'=>'200',
              'data'=> $estudio
            );


          }else{

            $data = array(
              'status'=> 'error',
              'code'=>'404',
              'msg'=> 'estudio no encontrado'
            );

          }

        }else{

          $data = array(
            'status'=> 'error',
            'code'=>'400',
            'msg'=> 'authorization not valid'
          );
        }

        return $helpers -> json($data);


      }


      public function buscarAction(Request $request, $buscar = null){

        //carga servicio helpers
        $helpers = $this->get(Helpers::class);
        //carga servicio de jwt y comprueba token
        $jwt_auth = $this->get(JwtAuth::class);

        //recoge el token
        $token = $request->get('authorization', null);

        //valida el token
        $authCheck = $jwt_auth -> checkToken($token);

        if($authCheck){
          $identity = $jwt_auth -> checkToken($token, true);//informacion usuario logueado

          $em = $this -> getDoctrine()->getManager();

          //Filtro
          $filter = $request -> get('filter', null);

          if(empty($filter)){
            $filter=null;
          }else if($filter==1){
            $filter = 'new';
          }else if($filter==2){
            $filter = 'todo';
          }

          //Orden
          $order = $request ->get('order', null);

          if(empty($order)|| $order ==2){
            $order ='DESC';
          }else{
            $order = 'ASC';
          }

          //Busqueda
          if($buscar != null){
            $dql= "SELECT e from BackendBundle:Estudio e "
            ."WHERE e.idusuario = $identity->sub AND "
            ."(e.nombreEstudio LIKE :buscar OR e.descripcionEstudio LIKE :buscar)";


          }else{
            $dql = "SELECT e FROM BackendBundle:Estudio e "
            ."WHERE e.idusuario = $identity->sub";
          }

          //SET FILTER
          if($filter != null){
            $dql.="AND e.updatedAt= :filter";
          }

          //SET order
          $dql .= " ORDER BY e.idestudio $order";

          $query = $em ->createQuery($dql);

          //SET PARAMETER FILTER
          if($filter != null){
          $query ->setParameter('filter',"filter");
          }

          //SET PARAMETER Busqueda
          if(!empty($buscar)){
            $query->setParameter('buscar', "%$buscar%");
          }

          $estudios = $query -> getResult();


          $data = array(
            'status'=> 'success',
            'code'=>'200',
            'data'=> 'algo'
          );


        }else{

          $data = array(
            'status'=> 'error',
            'code'=>'400',
            'msg'=> 'authorization not valid'
          );

        }
        return $helpers -> json($data);

}

        public function borrarAction(Request $request, $id=null){

          //carga servicio helpers
          $helpers = $this->get(Helpers::class);
          //carga servicio de jwt y comprueba token
          $jwt_auth = $this->get(JwtAuth::class);

          //recoge el token
          $token = $request->get('authorization', null);

          //valida el token
          $authCheck = $jwt_auth -> checkToken($token);

          if($authCheck){
            $identity = $jwt_auth -> checkToken($token, true);//informacion usuario logueado

            $em = $this->getDoctrine()->getManager();

            $estudio = $em->getRepository('BackendBundle:Estudio')->findOneBy(array(
              "idestudio"=>$id
            ));

            if($estudio && is_object($estudio) && $identity->sub== $estudio->getIdusuario()->getIdusuario()){

              //borrar objeto y estudio
              $em ->remove($estudio);
              $em->flush();

              $data = array(
                'status'=> 'success',
                'code'=>'200',
                'data'=> $estudio
              );


            }else{

              $data = array(
                'status'=> 'error',
                'code'=>'404',
                'msg'=> 'estudio no encontrado'
              );

            }

          }else{

            $data = array(
              'status'=> 'error',
              'code'=>'400',
              'msg'=> 'authorization not valid'
            );
          }

          return $helpers -> json($data);

        }
}
