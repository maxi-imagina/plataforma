<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Validator\Constraints as Assert;
use AppBundle\Services\Helpers;
use AppBundle\Services\JwtAuth;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }

    public function loginAction(Request $request){

      $helpers = $this->get(Helpers::class);

      //Recibir json por post
      $json = $request->get("json", null);

      //Array a devolver por defecto
      $data = array(
        'status' => 'error',
        'data'  => 'send json via post'

      );



      if($json != null){

        //hacer login

        // convertimos un json a un objeto de php
        $params = json_decode($json);

        $nombreusuario = (isset($params ->nombreusuario)) ? $params->nombreusuario : null;
        $passw = (isset($params->passw)) ? $params ->passw:null;
        $getHash = (isset($params->getHash)) ? $params ->getHash:null;



        if($nombreusuario != null && $passw != null){

          $jwt_auth = $this->get(JwtAuth::class);

          if($getHash==null || $getHash==false){
            $signup= $jwt_auth->signup($nombreusuario, $passw);
          }else{
            $signup=$jwt_auth->signup($nombreusuario, $passw, true);
          }



          return $this->json($signup);

        }else{

          $data = array(
            'status' => 'error',
            'data'  => 'Nombre de usuario incorrecto'
          );

        }




      }

      return $helpers->json($data);
    }

    public function pruebasAction(Request $request){
      $helpers = $this ->get(Helpers::class);
      $jwt_auth= $this ->get(JwtAuth::class);
      $token =$request->get("authorization", null);

      if($token && $jwt_auth->checkToken($token)==true){

      $em = $this->getDoctrine() -> getManager();
      $userRepo = $em -> getRepository("BackendBundle:Usuario");
      $users =$userRepo-> findAll();


      return  $helpers ->json(array(
        'status' => 'success',
        'users' => $users
      ));


    }else{
      return $helpers ->json(array(
        'status' => 'error',
        'code' => '400',
        'data' => 'Authorization not valid!!'
      ));
    }

      /*
      return new JsonResponse(array(
        'status' => 'success',
        'users' => $users[0]->getNombreusuario()
      ));

      die();
      */
    }
}
