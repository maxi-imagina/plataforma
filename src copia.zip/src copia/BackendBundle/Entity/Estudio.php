<?php

namespace BackendBundle\Entity;

/**
 * Estudio
 */
class Estudio
{
    /**
     * @var integer
     */
    private $idestudio;

    /**
     * @var string
     */
    private $nombreEstudio;

    /**
     * @var string
     */
    private $descripcionEstudio;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;

    /**
     * @var \BackendBundle\Entity\Usuario
     */
    private $idusuario;


    /**
     * Get idestudio
     *
     * @return integer
     */
    public function getIdestudio()
    {
        return $this->idestudio;
    }

    /**
     * Set nombreEstudio
     *
     * @param string $nombreEstudio
     *
     * @return Estudio
     */
    public function setNombreEstudio($nombreEstudio)
    {
        $this->nombreEstudio = $nombreEstudio;

        return $this;
    }

    /**
     * Get nombreEstudio
     *
     * @return string
     */
    public function getNombreEstudio()
    {
        return $this->nombreEstudio;
    }

    /**
     * Set descripcionEstudio
     *
     * @param string $descripcionEstudio
     *
     * @return Estudio
     */
    public function setDescripcionEstudio($descripcionEstudio)
    {
        $this->descripcionEstudio = $descripcionEstudio;

        return $this;
    }

    /**
     * Get descripcionEstudio
     *
     * @return string
     */
    public function getDescripcionEstudio()
    {
        return $this->descripcionEstudio;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Estudio
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Estudio
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set idusuario
     *
     * @param \BackendBundle\Entity\Usuario $idusuario
     *
     * @return Estudio
     */
    public function setIdusuario(\BackendBundle\Entity\Usuario $idusuario = null)
    {
        $this->idusuario = $idusuario;

        return $this;
    }

    /**
     * Get idusuario
     *
     * @return \BackendBundle\Entity\Usuario
     */
    public function getIdusuario()
    {
        return $this->idusuario;
    }
}

